

import UIKit

class ResultViewControllerrrr: UIViewController {

    @IBOutlet weak var resultTextView: UITextView!
    
    var resultText = ""
    var typeText = ""
    var inputName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resultTextView.text = "\(inputName) 님의 타입은 \(typeText) 입니다" + "\n" + resultText

        
    }

 
}
